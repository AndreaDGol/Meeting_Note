#!/bin/bash

# Azure Deployment Script for Notes Processing App - TESTING ENVIRONMENT
# This script deploys the application to Azure Container Apps with a separate testing URL

set -e  # Exit on error

# Configuration for TESTING environment
RESOURCE_GROUP="notes-app-rg"
ACR_NAME="golcondaregistry"
APP_NAME="notes-processing-app-test"  # Different app name for testing
ENV_NAME="notes-app-env"  # Can reuse the same environment
IMAGE_NAME="notes-app:latest"
LOCATION="westus2"
DB_SERVER_NAME="notes-db-server"
DB_NAME="notesdb"
DB_ADMIN_USER="notesadmin"
DB_ADMIN_PASSWORD="Golconda2024!Secure"
OPENAI_API_KEY="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"
ACR_USERNAME="golcondaregistry"

echo "🧪 Starting Azure Deployment - TESTING ENVIRONMENT..."
echo "======================================================"

# Check Docker is running
if ! docker ps &>/dev/null; then
    echo "❌ Docker is not running. Please start Docker Desktop and try again."
    exit 1
fi

# Check Azure login
if ! az account show &>/dev/null; then
    echo "Please login to Azure..."
    az login
fi

SUBSCRIPTION_ID=$(az account show --query id -o tsv)
echo "✅ Using subscription: $SUBSCRIPTION_ID"

# Get ACR password dynamically from Azure
echo ""
echo "📋 Getting ACR credentials..."
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv)
if [ -z "$ACR_PASSWORD" ]; then
    echo "❌ Failed to retrieve ACR password. Please check ACR admin user is enabled."
    exit 1
fi
echo "✅ ACR credentials retrieved"

# Step 1: Build and Push Docker Image
echo ""
echo "📋 Step 1: Building and pushing Docker image with email feature..."

# Login to ACR using Azure CLI
echo "Logging into Azure Container Registry..."
az acr login --name $ACR_NAME

# Build image for linux/amd64 platform (required for Azure)
echo "Building Docker image for linux/amd64 platform..."
docker build --platform linux/amd64 -t $ACR_NAME.azurecr.io/$IMAGE_NAME .

# Push image
echo "Pushing image to ACR..."
docker push $ACR_NAME.azurecr.io/$IMAGE_NAME

echo "✅ Image pushed successfully"

# Step 2: Check if environment exists
echo ""
echo "📋 Step 2: Checking Container Apps Environment..."
if az containerapp env show --name $ENV_NAME --resource-group $RESOURCE_GROUP &>/dev/null; then
    echo "✅ Container Apps Environment already exists: $ENV_NAME"
else
    echo "Creating Container Apps Environment..."
    az containerapp env create \
      --name $ENV_NAME \
      --resource-group $RESOURCE_GROUP \
      --location $LOCATION \
      --output none
    
    echo "✅ Container Apps Environment created"
fi

# Get database connection string
DB_FQDN="$DB_SERVER_NAME.postgres.database.azure.com"
DATABASE_URL="postgresql://$DB_ADMIN_USER:$DB_ADMIN_PASSWORD@$DB_FQDN:5432/$DB_NAME"

# Step 3: Create/Update Container App for Testing
echo ""
echo "📋 Step 3: Creating/Updating TEST Container App..."

# Check if test app exists
if az containerapp show --name $APP_NAME --resource-group $RESOURCE_GROUP &>/dev/null; then
    echo "Updating existing TEST Container App..."
    az containerapp update \
      --name $APP_NAME \
      --resource-group $RESOURCE_GROUP \
      --image $ACR_NAME.azurecr.io/$IMAGE_NAME \
      --output none
    echo "✅ TEST Container App updated"
else
    echo "Creating new TEST Container App..."
    # Create the container app first without the secret reference
    az containerapp create \
      --name $APP_NAME \
      --resource-group $RESOURCE_GROUP \
      --environment $ENV_NAME \
      --image $ACR_NAME.azurecr.io/$IMAGE_NAME \
      --registry-server $ACR_NAME.azurecr.io \
      --registry-username $ACR_USERNAME \
      --registry-password "$ACR_PASSWORD" \
      --target-port 8000 \
      --ingress external \
      --env-vars \
        "DATABASE_URL=$DATABASE_URL" \
        "DEBUG=False" \
        "HOST=0.0.0.0" \
        "PORT=8000" \
      --cpu 1.0 \
      --memory 2.0Gi \
      --min-replicas 1 \
      --max-replicas 3 \
      --output none
    
    echo "✅ TEST Container App created"
    
    # Now set the secret and update environment variable
    echo "Setting up OpenAI API key secret..."
    az containerapp secret set \
      --name $APP_NAME \
      --resource-group $RESOURCE_GROUP \
      --secrets "openai-key=$OPENAI_API_KEY" \
      --output none
    
    # Update environment variable to use secret
    az containerapp update \
      --name $APP_NAME \
      --resource-group $RESOURCE_GROUP \
      --set-env-vars "OPENAI_API_KEY=secretref:openai-key" \
      --output none
    
    echo "✅ Secrets configured"
fi

# Step 4: Get Public URL
echo ""
echo "📋 Step 4: Getting public URL..."
APP_URL=$(az containerapp show \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn \
  -o tsv)

echo ""
echo "======================================================"
echo "✅ TEST Deployment Complete!"
echo "======================================================"
echo ""
echo "🧪 TEST Environment URL: https://$APP_URL"
echo "📧 Email Feature Test URL: https://$APP_URL/email"
echo ""
echo "📝 Database Info (shared with main app):"
echo "   Server: $DB_FQDN"
echo "   Database: $DB_NAME"
echo "   Username: $DB_ADMIN_USER"
echo ""
echo "💡 Use https://$APP_URL/email to test the Outlook email feature!"
echo ""

