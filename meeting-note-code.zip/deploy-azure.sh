#!/bin/bash

# Azure Deployment Script for Notes Processing App
# This script deploys the application to Azure Container Apps with PostgreSQL

set -e  # Exit on error

# Configuration
RESOURCE_GROUP="notes-app-rg"
ACR_NAME="golcondaregistry"
APP_NAME="notes-processing-app"
ENV_NAME="notes-app-env"
IMAGE_NAME="notes-app:latest"
LOCATION="westus2"
DB_SERVER_NAME="notes-db-server"
DB_NAME="notesdb"
DB_ADMIN_USER="notesadmin"
DB_ADMIN_PASSWORD="Golconda2024!Secure"
OPENAI_API_KEY="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"
ACR_USERNAME="golcondaregistry"

echo "🚀 Starting Azure Deployment..."
echo "================================"

# Check Docker is running
if ! docker ps &>/dev/null; then
    echo "❌ Docker is not running. Please start Docker Desktop and try again."
    exit 1
fi

# Check Azure login
if ! az account show &>/dev/null; then
    echo "Please login to Azure..."
    az login
fi

SUBSCRIPTION_ID=$(az account show --query id -o tsv)
echo "✅ Using subscription: $SUBSCRIPTION_ID"

# Get ACR password dynamically from Azure
echo ""
echo "📋 Getting ACR credentials..."
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv)
if [ -z "$ACR_PASSWORD" ]; then
    echo "❌ Failed to retrieve ACR password. Please check ACR admin user is enabled."
    exit 1
fi
echo "✅ ACR credentials retrieved"

# Step 1: Check PostgreSQL provider registration
echo ""
echo "📋 Step 1: Checking PostgreSQL provider registration..."
REGISTRATION_STATE=$(az provider show -n Microsoft.DBforPostgreSQL --query "registrationState" -o tsv 2>/dev/null || echo "NotRegistered")
if [ "$REGISTRATION_STATE" != "Registered" ]; then
    echo "Registering PostgreSQL provider (this may take a few minutes)..."
    az provider register --namespace Microsoft.DBforPostgreSQL
    echo "⏳ Waiting for registration to complete..."
    while [ "$(az provider show -n Microsoft.DBforPostgreSQL --query 'registrationState' -o tsv)" != "Registered" ]; do
        sleep 10
        echo "Still registering..."
    done
    echo "✅ PostgreSQL provider registered"
else
    echo "✅ PostgreSQL provider already registered"
fi

# Step 2: Create PostgreSQL Database
echo ""
echo "📋 Step 2: Creating PostgreSQL Database..."
echo "This may take 5-10 minutes..."

# Check if server already exists
if az postgres flexible-server show --resource-group $RESOURCE_GROUP --name $DB_SERVER_NAME &>/dev/null; then
    echo "✅ PostgreSQL server already exists: $DB_SERVER_NAME"
else
    # Create PostgreSQL Flexible Server
    az postgres flexible-server create \
      --resource-group $RESOURCE_GROUP \
      --name $DB_SERVER_NAME \
      --location $LOCATION \
      --admin-user $DB_ADMIN_USER \
      --admin-password "$DB_ADMIN_PASSWORD" \
      --sku-name Standard_B1ms \
      --tier Burstable \
      --version 14 \
      --storage-size 32 \
      --public-access 0.0.0.0 \
      --output none
    
    echo "✅ PostgreSQL server created: $DB_SERVER_NAME"
fi

# Create database if it doesn't exist
if az postgres flexible-server db show --resource-group $RESOURCE_GROUP --server-name $DB_SERVER_NAME --database-name $DB_NAME &>/dev/null; then
    echo "✅ Database already exists: $DB_NAME"
else
    az postgres flexible-server db create \
      --resource-group $RESOURCE_GROUP \
      --server-name $DB_SERVER_NAME \
      --database-name $DB_NAME \
      --output none
    
    echo "✅ Database created: $DB_NAME"
fi

# Get database connection string
DB_FQDN="$DB_SERVER_NAME.postgres.database.azure.com"
DATABASE_URL="postgresql://$DB_ADMIN_USER:$DB_ADMIN_PASSWORD@$DB_FQDN:5432/$DB_NAME"

echo ""
echo "📝 Database Info:"
echo "   Server: $DB_FQDN"
echo "   Database: $DB_NAME"
echo "   Username: $DB_ADMIN_USER"

# Step 3: Build and Push Docker Image
echo ""
echo "📋 Step 3: Building and pushing Docker image..."

# Login to ACR using Azure CLI (more reliable)
echo "Logging into Azure Container Registry..."
az acr login --name $ACR_NAME

# Alternative: If the above doesn't work, try direct password login
# echo "$ACR_PASSWORD" | docker login $ACR_NAME.azurecr.io -u $ACR_USERNAME --password-stdin

# Build image
echo "Building Docker image..."
docker build -t $ACR_NAME.azurecr.io/$IMAGE_NAME .

# Push image
echo "Pushing image to ACR..."
docker push $ACR_NAME.azurecr.io/$IMAGE_NAME

echo "✅ Image pushed successfully"

# Step 4: Register Container Apps provider
echo ""
echo "📋 Step 4: Checking Container Apps provider..."
REGISTRATION_STATE=$(az provider show -n Microsoft.App --query "registrationState" -o tsv 2>/dev/null || echo "NotRegistered")
if [ "$REGISTRATION_STATE" != "Registered" ]; then
    echo "Registering Container Apps provider..."
    az provider register --namespace Microsoft.App
    echo "⏳ Waiting for registration to complete..."
    while [ "$(az provider show -n Microsoft.App --query 'registrationState' -o tsv)" != "Registered" ]; do
        sleep 10
    done
    echo "✅ Container Apps provider registered"
else
    echo "✅ Container Apps provider already registered"
fi

# Step 5: Create Container Apps Environment
echo ""
echo "📋 Step 5: Creating Container Apps Environment..."
if az containerapp env show --name $ENV_NAME --resource-group $RESOURCE_GROUP &>/dev/null; then
    echo "✅ Container Apps Environment already exists"
else
    az containerapp env create \
      --name $ENV_NAME \
      --resource-group $RESOURCE_GROUP \
      --location $LOCATION \
      --output none
    
    echo "✅ Container Apps Environment created"
fi

# Step 6: Create/Update Container App
echo ""
echo "📋 Step 6: Creating/Updating Container App..."

# Check if app exists
if az containerapp show --name $APP_NAME --resource-group $RESOURCE_GROUP &>/dev/null; then
    echo "Updating existing Container App..."
    az containerapp update \
      --name $APP_NAME \
      --resource-group $RESOURCE_GROUP \
      --image $ACR_NAME.azurecr.io/$IMAGE_NAME \
      --output none
    echo "✅ Container App updated"
else
    echo "Creating new Container App..."
    az containerapp create \
      --name $APP_NAME \
      --resource-group $RESOURCE_GROUP \
      --environment $ENV_NAME \
      --image $ACR_NAME.azurecr.io/$IMAGE_NAME \
      --registry-server $ACR_NAME.azurecr.io \
      --registry-username $ACR_USERNAME \
      --registry-password "$ACR_PASSWORD" \
      --target-port 8000 \
      --ingress external \
      --env-vars \
        "DATABASE_URL=$DATABASE_URL" \
        "DEBUG=False" \
        "HOST=0.0.0.0" \
        "PORT=8000" \
      --secrets \
        "openai-key=$OPENAI_API_KEY" \
      --secret-env-vars \
        "OPENAI_API_KEY=openai-key" \
      --cpu 1.0 \
      --memory 2.0Gi \
      --min-replicas 1 \
      --max-replicas 3 \
      --output none
    
    echo "✅ Container App created"
fi

# Step 7: Get Public URL
echo ""
echo "📋 Step 7: Getting public URL..."
APP_URL=$(az containerapp show \
  --name $APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn \
  -o tsv)

echo ""
echo "================================"
echo "✅ Deployment Complete!"
echo "================================"
echo ""
echo "🌐 Your web URL: https://$APP_URL"
echo ""
echo "📝 Database Info:"
echo "   Server: $DB_FQDN"
echo "   Database: $DB_NAME"
echo "   Username: $DB_ADMIN_USER"
echo "   Password: $DB_ADMIN_PASSWORD"
echo ""
echo "💡 Save the database password securely!"
echo ""

